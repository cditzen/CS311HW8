package cs311.hw7.graph;

import cs311.hw7.graphalgorithms.Weight;

import java.util.*;

import static cs311.hw7.graphalgorithms.GraphAlgorithms.*;

/**
 * Created by cditzen on 10/31/2016.
 */
public class Graph<V, E> implements IGraph<V, E> {

    /** Indicates whether or not the graph is directed. */
    private boolean isDirected;

    /** Hashmap containing all vertices in the graph */
    private HashMap<Integer, Vertex<V>> vertexHashMap;

    /** Hashmap containing all edges in the graph */
    private HashMap<Integer, Edge<E>> edgeHashMap;

    /**
     * Initializes a new Graph where isDirected specified
     * @param isDirected Whether or not a graph is directed
     */
    public Graph(boolean isDirected) {
        vertexHashMap = new HashMap<>();
        edgeHashMap = new HashMap<>();

        this.isDirected = isDirected;
    }

    /**
     * Initializes a new directed graph
     */
    public Graph() {
        vertexHashMap = new HashMap<>();
        edgeHashMap = new HashMap<>();
        this.isDirected = true;
    }

    /**
     * Set the graph to be a directed graph.  Edge (x, y) is different than edge (y, x)
     */
    @Override
    public void setDirectedGraph() {
        isDirected = true;
    }

    /**
     * Set the graph to be an undirected graph.  Edge (x, y) is in the graph
     * if and only if edge (y, x) is in the graph.  Note that when implementing this
     * and there are already edges defined in the graph, care must be taken to
     * resolve conflicts and inconsistencies in the overall implementation.
     *
     * Multiple edges between two vertices will be deleted only if they contain the same data.
     *
     * This runs in O(E) time in order to ensure all duplicate edges are deleted.
     */
    @Override
    public void setUndirectedGraph() {
        List<Edge<E>> edges = getEdges();
        for (Edge edge : edges) {
            Edge duplicateEdge = getEdge(edge.getVertexName2(), edge.getVertexName1());
            if (duplicateEdge != null) {
                if (edge.getEdgeData() == null) {
                    edgeHashMap.remove(edge.hashCode());
                } else if (duplicateEdge.getEdgeData() != null && duplicateEdge.getEdgeData().equals(edge.getEdgeData())) {
                    edgeHashMap.remove(edge.hashCode());
                }
            }
        }
        isDirected = false;
    }

    /**
     *
     * @return true if the graph is directed.
     */
    @Override
    public boolean isDirectedGraph() {
        return isDirected;
    }

    /**
     * Adds a vertex to the graph with name given by the vertexName.  vertexNames,
     * must be unique in the graph.
     *
     * @param vertexName The unique name of the vertex.
     *
     * @throws IGraph.DuplicateVertexException
     */
    @Override
    public void addVertex(String vertexName) throws DuplicateVertexException {
        addVertex(vertexName, null);
    }

    /**
     * Adds a vertex to the graph with name given by the vertexName.  vertexNames,
     * must be unique in the graph.  The vertexData of generic type is associated with
     * this vertex.
     *
     * It takes O(1) time to add a vertex to vertexHashMap
     *
     * @param vertexName
     * @param vertexData
     * @throws IGraph.DuplicateVertexException
     */
    @Override
    public void addVertex(String vertexName, Object vertexData) throws DuplicateVertexException {
        if (getVertex(vertexName) != null) {
            throw new DuplicateVertexException();
        } else {
            Vertex<V> vertex = new Vertex(vertexName, vertexData);
            vertexHashMap.put(vertex.hashCode(), vertex);
        }
    }

    /**
     * Adds an edge to the graph by specifying the two vertices that comprise the
     * edge.  If the graph is undirected then edge (x, y) or edge (y, x) may be used
     * to add the single edge.  If the graph is undirected and edge (x,y) is added
     * followed by a subsequent edge (y, x), the later add would throw a
     * DuplicateEdgeException.
     *
     * @param vertex1 The first vertex in the edge.
     * @param vertex2 The second vertex in the edge.
     *
     * @throws IGraph.DuplicateEdgeException
     * @throws IGraph.NoSuchVertexException
     */
    @Override
    public void addEdge(String vertex1, String vertex2) throws DuplicateEdgeException, NoSuchVertexException {
        addEdge(vertex1, vertex2, null);
    }

    /**
     * Adds an edge to the graph by specifying the two vertices that comprise the
     * edge.  If the graph is undirected then edge (x, y) or edge (y, x) may be used
     * to add the single edge.  If the graph is undirected and edge (x,y) is added
     * followed by a subsequent edge (y, x), the later add would throw a
     * DuplicateEdgeException.  The edgeData parameter is used to associate generic
     * edge data with the edge.
     *
     * If either vertex doesn't exist or if the edge already exists, a runtime exception is thrown.
     *
     * It takes O(1) time to add an Edge to edgeHashmap
     *
     * @param vertex1 The first vertex in the edge.
     * @param vertex2 The second vertex in the edge.
     * @param edgeData The generic edge data.
     *
     * @throws IGraph.DuplicateEdgeException
     * @throws IGraph.NoSuchVertexException
     */
    @Override
    public void addEdge(String vertex1, String vertex2, Object edgeData) throws DuplicateEdgeException, NoSuchVertexException {
        if (getVertex(vertex1) == null || getVertex(vertex2) == null) {
            throw new NoSuchVertexException();
        } else if (getEdge(vertex1, vertex2) != null) {
            // Note: This accounts for interchangeable vertices if the graph is undirected
            throw new DuplicateEdgeException();
        } else {
            Edge<E> edge = new Edge(vertex1, vertex2, edgeData);
            edgeHashMap.put(edge.hashCode(), edge);
        }
    }

    /**
     * Returns the generic vertex data associated with the specified vertex.  If no
     * vertex data is associated with the vertex, then null is returned.
     *
     * @param vertexName  Name of vertex to get data for
     *
     * @return The generic vertex data
     *
     * @throws IGraph.NoSuchVertexException
     */
    @Override
    public V getVertexData(String vertexName) throws NoSuchVertexException {
        Vertex v = getVertex(vertexName);
        if (v == null) {
            throw new NoSuchVertexException();
        } else {
            return (V) v.getVertexData();
        }
    }

    /**
     * Sets the generic vertex data of the specified vertex by removing the original vertex and
     * adding a new one containing the updated data.
     *
     * It takes O(1) time to delete and add a new vertex
     *
     * @param vertexName The name of the vertex.
     *
     * @param vertexData The generic vertex data.
     *
     * @throws IGraph.NoSuchVertexException
     */
    @Override
    public void setVertexData(String vertexName, Object vertexData) throws NoSuchVertexException {
        Vertex v = getVertex(vertexName);
        if (v == null) {
            throw new NoSuchVertexException();
        } else {
            vertexHashMap.remove(v.hashCode(), v);
            Vertex <V> updatedVertex = new Vertex(vertexName, vertexData);
            vertexHashMap.put(updatedVertex.hashCode(), updatedVertex);
        }
    }

    /**
     * Returns the generic edge data associated with the specified edge.  If no
     * edge data is associated with the edge, then null is returned.
     *
     * If either specified vertex doesn't exist, or if the edge doesn't exist,
     * a runtime exception is thrown
     *
     * It takes O(1) time to find an edge from edgeHashMap and retrieve its data.
     *
     * @param vertex1 Vertex one of the edge.
     * @param vertex2 Vertex two of the edge.
     *
     * @return The generic edge data.
     *
     * @throws IGraph.NoSuchVertexException
     * @throws IGraph.NoSuchEdgeException
     */
    @Override
    public E getEdgeData(String vertex1, String vertex2) throws NoSuchVertexException, NoSuchEdgeException {
        if (getVertex(vertex1) == null || getVertex(vertex2) == null) {
            throw new NoSuchVertexException();
        }
        Edge e = getEdge(vertex1, vertex2);
        if (e == null) {
            throw new NoSuchEdgeException();
        }
        return (E) e.getEdgeData();
    }

    /**
     * Sets the generic edge data of the specified edge by removing the original edge and
     * adding a new one containing the updated data.
     *
     * It takes O(1) time to find and replace an edge from edgeHashMap
     *
     * @param vertex1  Vertex one of the edge.
     * @param vertex2  Vertex two of the edge.
     *
     * @param edgeData The generic edge data.
     *
     * @throws IGraph.NoSuchVertexException
     * @throws IGraph.NoSuchEdgeException
     */
    @Override
    public void setEdgeData(String vertex1, String vertex2, Object edgeData) throws NoSuchVertexException, NoSuchEdgeException {
        if (getVertex(vertex1) == null || getVertex(vertex2) == null) {
            throw new NoSuchVertexException();
        }
        Edge e = getEdge(vertex1, vertex2);
        if (e == null) {
            throw new NoSuchEdgeException();
        } else {
            edgeHashMap.remove(e.hashCode(), e);
            Edge updatedEdge = new Edge(vertex1, vertex2, edgeData);
            edgeHashMap.put(updatedEdge.hashCode(), updatedEdge);
        }
    }

    /**
     * Returns an encapsulated Vertex data type based on the vertex name
     *
     * It takes O(1) time to retrieve a vertex from vertexHashMap
     *
     * @param VertexName The name of the vertex.
     *
     * @return The encapsulated vertex.
     */
    @Override
    public Vertex getVertex(String VertexName) {
        Vertex v = new Vertex(VertexName, null);
        return vertexHashMap.get(v.hashCode());
    }

    /**
     * Returns an encapsulated Edge data type based on the specified edge.
     * If the graph is directed, vertex 1 and 2 may not be interchanged.
     * If the graph is undirected, vertex 1 and 2 may be interchanged.
     *
     * It takes O(1) time to retrieve an edge from edgeHashMap
     *
     * @param vertexName1 Vertex one of edge.
     * @param vertexName2 Vertex two of edge.
     *
     * @return Encapsulated edge.
     */
    @Override
    public Edge getEdge(String vertexName1, String vertexName2) {
        Edge e = new Edge(vertexName1, vertexName2, null);
        Edge edge = edgeHashMap.get(e.hashCode());
        if (edge == null && !isDirected) {
            e = new Edge(vertexName2, vertexName1, null);
            edge = edgeHashMap.get(e.hashCode());
        }
        return edge;
    }

    /**
     * Returns a list of all the vertices in the graph.
     *
     * It takes O(V) to retrieve all vertices
     *
     * @return The List<Vertex> of vertices.
     */
    @Override
    public List<Vertex<V>> getVertices() {
        return new ArrayList<Vertex<V>>(vertexHashMap.values());
    }

    /**
     * Returns all the edges in the graph.
     *
     * It takes O(E) to retrieve all edges
     *
     * @return The List<Edge> of edges.
     */
    @Override
    public List<Edge<E>> getEdges() {
        return new ArrayList<Edge<E>>(edgeHashMap.values());
    }

    /**
     * Returns all the neighbors of a specified vertex.
     *
     * It takes O(V) time to iterate through all vertices to find neighbors
     *
     * @param vertex The vertex to return neighbors for.
     *
     * @return The list of vertices that are the neighbors of the specified vertex.
     */
    @Override
    public List<Vertex<V>> getNeighbors(String vertex) {
        ArrayList<Vertex<V>> neighbors = new ArrayList<>();
        for (Vertex otherVertex : getVertices()) {
            Edge edge = getEdge(vertex, otherVertex.getVertexName());
            // This accounts for reverse edges if the graph is undirected
            if (edge != null) {
                neighbors.add(otherVertex);
            }
        }
        return neighbors;
    }
}