package cs311.hw7.graphalgorithms;

import cs311.hw7.graph.IGraph;

/**
 * Created by cditz_000 on 11/6/2016.
 */
public class Weight implements IWeight {

    private double weight;

    public Weight(double weight) {
        this.weight = weight;
    }

    @Override
    public double getWeight() {
        return weight;
    }
}
